import { helloWorld } from "./helloworld"

console.log(helloWorld());